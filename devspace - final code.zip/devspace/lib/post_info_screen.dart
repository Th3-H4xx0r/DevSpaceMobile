import 'package:flutter/material.dart';

class PostInfoScreen extends StatefulWidget {

  PostInfoScreen(givenLink, givenTitle){
    link = givenLink;
    title = givenTitle;
  }

  var link = "";
  var title = "";
  @override
  PostInfoScreenState createState() => PostInfoScreenState();
}

class PostInfoScreenState extends State<PostInfoScreen> {
  final List<String> name = <String>['John Doe'];
  final List<String> job = <String>[
    'UI/UX Developer',
  ];

  static const Opacity opacity = Opacity(opacity: 0.5);
  @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        backgroundColor: Color.fromRGBO(17, 17, 17, 1),
        body: ListView(
          children: <Widget>[

            Row(
              children: <Widget>[
                SizedBox(
                  width: 10,
                ),
                IconButton(
                  icon: Icon(Icons.keyboard_backspace, color: Colors.white,),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
            GestureDetector(
              onTap: () {
              },
              child: Hero(
                tag: 'Information',
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: 300,
                  decoration: BoxDecoration(
                      color: Colors.black,
                      image: DecorationImage(
                          image: NetworkImage(
                              widget.link),
                          fit: BoxFit.cover),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(40),
                          bottomRight: Radius.circular(40))),
                ),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              child: Text(
              widget.title,
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 10),
            Container(
              padding: EdgeInsets.only(left: 10),
              child: ListTile(
                  leading: Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: NetworkImage(
                                'https://miro.medium.com/max/785/0*Ggt-XwliwAO6QURi.jpg'),
                            fit: BoxFit.cover),
                        shape: BoxShape.circle),
                  ),
                  title: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('John Doe',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold)),
                      SizedBox(height: 5),
                      Text('UI/UX Developer',
                          style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.bold))
                    ],
                  )),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 0),
              child: Text(
              "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).",
                style: TextStyle(
                    color: Colors.grey[700],
                    fontSize: 15,
                    fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
      ),
    );
  }
}