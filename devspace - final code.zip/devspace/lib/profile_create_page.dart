import 'package:devspace/nav_bar_main.dart';
import 'package:devspace/recent_posts_screen.dart';
import 'package:flutter/material.dart';
import 'datamanagement.dart';

class ProfileCreatePage extends StatefulWidget {
  @override
  _ProfileCreatePageState createState() => _ProfileCreatePageState();
}

class _ProfileCreatePageState extends State<ProfileCreatePage> {

  //Instances
  var dataManagementInstance = DataManagement();


  //Controller
  TextEditingController skillController = TextEditingController();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController degreeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          elevation: 0,
            backgroundColor: Color.fromRGBO(21, 21, 21, 1),
            title: Container(
              padding: EdgeInsets.only(top: 10, left: 10),
              child: Text(
                "My Skills",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold),
              ),
            )),
        backgroundColor: Color.fromRGBO(21, 21, 21, 1),
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 80,
              ),
              Container(
                padding: EdgeInsets.only(left: 30, bottom: 20),
                alignment: Alignment.centerLeft,
                child: Text(
                  "I Speacialize in",
                  style: TextStyle(
                      color: Color.fromRGBO(204, 204, 204, 1),
                      fontWeight: FontWeight.w500),
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                      color: Color.fromRGBO(62, 62, 62, 1),
                      borderRadius: BorderRadius.circular(10)),
                  height: 40,
                  width: MediaQuery.of(context).size.width - 60,
                  child: Container(
                    padding: EdgeInsets.only(top: 5, bottom: 1, left: 10),
                    child: TextField(
                      style: TextStyle(color: Color.fromRGBO(146, 146, 146, 1)),
                      controller: skillController,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "ex. Android Developer",
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(99, 99, 99, 1)),
                          suffixIcon: Icon(
                            Icons.search,
                            color: Color.fromRGBO(99, 99, 99, 1),
                          )),
                    ),
                  )),
              SizedBox(
                height: 30,
              ),
              Container(
                padding: EdgeInsets.only(left: 30, bottom: 20),
                alignment: Alignment.centerLeft,
                child: Text(
                  "First Name",
                  style: TextStyle(
                      color: Color.fromRGBO(204, 204, 204, 1),
                      fontWeight: FontWeight.w500),
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                      color: Color.fromRGBO(62, 62, 62, 1),
                      borderRadius: BorderRadius.circular(10)),
                  height: 40,
                  width: MediaQuery.of(context).size.width - 60,
                  child: Container(
                    padding: EdgeInsets.only(top: 5, bottom: 1, left: 10),
                    child: TextField(
                      style: TextStyle(color: Color.fromRGBO(146, 146, 146, 1)),
                      controller: firstNameController,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "ex. John",
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(99, 99, 99, 1)),
                          suffixIcon: Icon(
                            Icons.search,
                            color: Color.fromRGBO(99, 99, 99, 1),
                          )),
                    ),
                  )),
              SizedBox(
                height: 30,
              ),
              Container(
                padding: EdgeInsets.only(left: 30, bottom: 20),
                alignment: Alignment.centerLeft,
                child: Text(
                  "Last Name",
                  style: TextStyle(
                      color: Color.fromRGBO(204, 204, 204, 1),
                      fontWeight: FontWeight.w500),
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                      color: Color.fromRGBO(62, 62, 62, 1),
                      borderRadius: BorderRadius.circular(10)),
                  height: 40,
                  width: MediaQuery.of(context).size.width - 60,
                  child: Container(
                    padding: EdgeInsets.only(top: 5, bottom: 1, left: 10),
                    child: TextField(
                      style: TextStyle(color: Color.fromRGBO(146, 146, 146, 1)),
                      controller: lastNameController,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "ex. Doe",
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(99, 99, 99, 1)),
                          suffixIcon: Icon(
                            Icons.search,
                            color: Color.fromRGBO(99, 99, 99, 1),
                          )),
                    ),
                  )),
              SizedBox(
                height: 30,
              ),
              Container(
                padding: EdgeInsets.only(left: 30, bottom: 20),
                alignment: Alignment.centerLeft,
                child: Text(
                  "Degree",
                  style: TextStyle(
                      color: Color.fromRGBO(204, 204, 204, 1),
                      fontWeight: FontWeight.w500),
                ),
              ),
              Container(
                  decoration: BoxDecoration(
                      color: Color.fromRGBO(62, 62, 62, 1),
                      borderRadius: BorderRadius.circular(10)),
                  height: 40,
                  width: MediaQuery.of(context).size.width - 60,
                  child: Container(
                    padding: EdgeInsets.only(top: 5, bottom: 1, left: 10),
                    child: TextField(
                      style: TextStyle(color: Color.fromRGBO(146, 146, 146, 1)),
                      controller: degreeController,
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "ex. Masters Degree",
                          hintStyle:
                              TextStyle(color: Color.fromRGBO(99, 99, 99, 1)),
                          suffixIcon: Icon(
                            Icons.search,
                            color: Color.fromRGBO(99, 99, 99, 1),
                          )),
                    ),
                  )),
              Expanded(
                child: Container(),
              ),

              Container(
                height: 40,
                width: 150,
                child: Card(
                  color: Color.fromRGBO(62, 62, 62, 1),
                  child: InkWell(
                    onTap: () async{
                      await dataManagementInstance.saveUserInfo(
                          firstNameController.text,
                          lastNameController.text,
                          skillController.text,
                          degreeController.text
                      );

                      Navigator.push(context, MaterialPageRoute(builder: (context) => GoogleNavBar()));
                    },
                    splashColor: Colors.grey,
                    child: Center(
                      child: Text(
                        "Continue",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500,
                            color: Color.fromRGBO(204, 204, 204, 1)),
                      ),
                    ),
                  ),
                ),
              ),

              SizedBox(
                height: 40,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
