import 'package:devspace/post_info_screen.dart';
import 'package:flutter/material.dart';

class RecentPosts extends StatefulWidget {
  @override
  _RecentPostsState createState() => _RecentPostsState();
}

class _RecentPostsState extends State<RecentPosts> {

  //Global Variables
  var listHeight = 1000.0;
  var recentPosts = [
    ["Flutter", "New Flutter March Update", "Shabd Veyyakula 04 March, 2020", "https://code.org/shared/images/social-media/codeorg2019_social.png"],
    ["Flutter", "New Flutter March Update", "Shabd Veyyakula 04 March, 2020", "https://image.shutterstock.com/image-vector/young-man-sitting-office-work-260nw-1086055667.jpg"]
  ];

  var popularPosts = [
    ["Flutter", "New Flutter March Update", "Shabd Veyyakula 04 March, 2020", "https://plugins.jetbrains.com/files/9212/81440/icon/META-INF_pluginIcon.svg"],
    ["JavaScript", "The new update sucks!", "Shabd Veyyakula 04 March, 2020", "https://pluralsight2.imgix.net/paths/images/javascript-542e10ea6e.png"],
    ["NodeJS", "Node JS is getting shut down", "Shabd Veyyakula 04 March, 2020", "https://images.g2crowd.com/uploads/product/image/social_landscape/social_landscape_f0b606abb6d19089febc9faeeba5bc05/nodejs-development-services.png"],
    ["Flutter", "No more support with firebase", "Shabd Veyyakula 04 March, 2020", "https://plugins.jetbrains.com/files/9212/81440/icon/META-INF_pluginIcon.svg"],
    ["Firebase", "Realtime database deprecation", "Shabd Veyyakula 04 March, 2020", "https://pbs.twimg.com/profile_images/1012243829477392387/m3cEA33V_400x400.jpg"]
  ];

  @override
  void initState() {
    setState(() {
      listHeight = 0;
      listHeight = double.parse(popularPosts.length.toString()) * 110;
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          elevation: 0,
            backgroundColor: Color.fromRGBO(21, 21, 21, 1),
            title: Container(
              padding: EdgeInsets.only(top: 10, left: 5),
              child: Text(
                "Recent Posts",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold),
              ),
            )),
        backgroundColor: Color.fromRGBO(21, 21, 21, 1),
        body: ListView(
          physics: BouncingScrollPhysics(),
          children: <Widget>[
            SizedBox(
              height: 20,
            ),
            Container(
              height: 200,
              child: ListView.builder(
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: recentPosts.length,
                itemBuilder: (context, int index) {
                  return Row(
                    children: <Widget>[
                      SizedBox(
                        width: 20,
                      ),
                      GestureDetector(
                        child: Container(
                            height: 200,
                            width: 300,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20)
                            ),
                            child: ClipRRect(
                              child: Image.network(recentPosts[index][3], fit: BoxFit.cover,),
                              borderRadius: BorderRadius.circular(20),
                            )
                        ),
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => PostInfoScreen(recentPosts[index][3], recentPosts[index][1])));
                        },
                      ),
                    ],
                  );
                },
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              padding: EdgeInsets.only(left: 20, bottom: 20),
              child: Text(
                "Popular Posts",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              height: listHeight,
              child: ListView.builder(
                itemCount: popularPosts.length,
                physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, int index) {
                return Column(
                  children: <Widget>[
                    Container(
                      child: Row(
                        children: <Widget>[
                          Container(
                            height: 80,
                            width: 80,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white
                            ),
                            child: Image.network(popularPosts[index][3], fit: BoxFit.cover,),
                          ),
                          SizedBox(
                            width: 20,
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                  child: Text(
                                    popularPosts[index][0],
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w600),
                              )),

                              Container(
                                padding: EdgeInsets.only(
                                  top: 5
                                ),
                                  child: Text(
                                    popularPosts[index][1],
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600),
                              )),

                              Container(
                                  padding: EdgeInsets.only(
                                      top: 5
                                  ),
                                  child: Text(
                                    popularPosts[index][2],
                                style: TextStyle(
                                    color: Color.fromRGBO(169, 169, 169, 1)),
                              )),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                  ],
                );
              }),
            )
          ],
        ),
      ),
    );
  }
}
