import 'package:firebase_database/firebase_database.dart';

class DataManagement{

  Future saveUserInfo(String first, String last, String skill, String degree) async {

    DatabaseReference databaseReference = FirebaseDatabase.instance.reference().child("Users").child(first + " " + last);

    databaseReference.child("Name").set(first + " " + last);

    databaseReference.child("Main Skill").set(skill);

    databaseReference.child("Degree").set(degree);
  }

}