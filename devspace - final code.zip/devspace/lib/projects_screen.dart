import 'package:devspace/project_info_screen.dart';
import 'package:flutter/material.dart';

class ProjectsScreen extends StatefulWidget {
  @override
  ProjectsScreenState createState() => ProjectsScreenState();
}

class ProjectsScreenState extends State<ProjectsScreen> {
  final List<String> projectname = <String>[
    'Procura',
    'Canvas',
    'Delivery Deck'
  ];
  final List<String> description = <String>[
    'An app that takes hackathon managent...',
    'Canavas is a academic management...',
    'Delivery Deck is a delivery software...'
  ];

  final List<String> needed = <String>[
    'UI/UX Designer and Android Dev Needed',
    'IOS Dev and Database Dev Needed',
    'Web Developer Needed'
  ];
  final List<int> members = <int>[3, 2, 6];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(21, 21, 21, 1),
      body: Column(children: <Widget>[
        SizedBox(
          height: 80,
        ),
        Row(
          children: <Widget>[
            SizedBox(width: 40),
            Text(
              'Projects',
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 32),
            ),
          ],
        ),
        SizedBox(height: 30),
        Center(
          child: Container(
            width: MediaQuery.of(context).size.width - 50,
            height: 40,
            child: Center(
                child: Row(
                  children: <Widget>[
                    SizedBox(width: 20),
                    Text('Search',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Colors.grey[800])),
                  ],
                )),
            decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(7)),
          ),
        ),
        SizedBox(height: 20),
        Container(
          child: ListView.builder(
            physics: BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 8),
              itemCount: projectname.length,
              itemBuilder: (BuildContext context, int index) {
                return GestureDetector(
                  onTap: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ProjectInfoScreen()));
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Container(
                        height: 100,
                        decoration: BoxDecoration(
                            color: Colors.grey[900].withOpacity(0.7),
                            borderRadius: BorderRadius.circular(15)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Text('${projectname[index]}',
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.grey[100])),
                                  Row(
                                    children: <Widget>[
                                      Text('${members[index]} ',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.grey[100])),
                                      Icon(Icons.people,color: Colors.white,)
                                    ],
                                  )
                                ],
                              ),
                              SizedBox(height: 5),
                              Text('${description[index]}',
                                  style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      color: Color.fromRGBO(146, 146, 146, 1))),
                              Container(
                                  padding: EdgeInsets.only(top: 5),
                                  alignment: Alignment.centerLeft,
                                  child: Text('${needed[index]}',
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: Color.fromRGBO(99, 99, 99, 1)))
                              ),
                            ],
                          ),
                        )),
                  ),
                );
              }),
          width: MediaQuery.of(context).size.width - 50,
          height: MediaQuery.of(context).size.height / 2 + 155,
        )
      ]),
    );
  }
}