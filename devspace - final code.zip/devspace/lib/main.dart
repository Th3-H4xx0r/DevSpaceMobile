import 'package:devspace/profile_create_page.dart';
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: SplashScreen()));

class SplashScreen extends StatefulWidget {
  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    Future.delayed(Duration(milliseconds: 2000)).then((_){
      Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileCreatePage()));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color.fromRGBO(21, 21, 21, 1),
        body: Center(
          child: Container(
            height: 100,
            width: 100,
            child: Image.asset("lib/Assets/appicon.png"),
          )
        ),
      ),
    );
  }
}

